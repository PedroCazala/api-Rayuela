"use strict";
// import { IProduct } from "../interfaces/products.interface";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShipmentsService = void 0;
class ShipmentsService {
}
exports.ShipmentsService = ShipmentsService;
